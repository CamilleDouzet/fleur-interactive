
#include "lpc17xx.h"
#include "ocf_lpc176x_lib.h"
#include <stdio.h>

void printError(const char * str);
int main()
{

   SysTick_Config(SystemCoreClock/100);       /* Generate interrupt each 10 ms */

    /* Initialize All the Four UARTs with different Baud rate */
  initUART0();
printError("teeeeest 1 ");
    while(1)
    {
        /*UARTx_Printf, where suffix "x" specifies the UART channel(0-3)*/
       
        printError("teeeeest 2 ");
    }
}
void printError(const char * str)
{
	/*Print error and enter infinite loop to HALT program*/
	printf("%s\n",str);
	//while(1);
}