#include <stdlib.h>

/* Scheduler include files. */
#include "FreeRTOS.h"
#include "task.h"
#include "ocf_lpc176x_lib.h"
#include <stdio.h>  

/* le fichier .h du TP  */
#include "myTasks.h"

// #define ledSTACK_SIZE		128

unsigned int delay = 500;

/* d�claration des diverses taches avec la fonction prototype */
//static portTASK_FUNCTION_PROTO( vLed1Task, pvParameters );//exemple de d�claration
static portTASK_FUNCTION_PROTO( Tache_Pot, pvParameters );//exemple de d�claration
/*-------------------variables globales propres aux taches------------*/
#define ledSTACK_SIZE 128
#define echantillonage_codeur 1


#define VREF       3.3 //Reference Voltage at VREFP pin, given VREFN = 0V(GND)
#define ADC_CLK_EN (1<<12)
#define SEL_AD0_0  (1<<0) //Select Channel AD0.0 
#define CLKDIV     1 //ADC clock-divider (ADC_CLOCK=PCLK/CLKDIV+1) = 12.5Mhz @ 25Mhz PCLK
#define PWRUP      (1<<21) //setting it to 0 will power it down
#define START_CNV  (1<<24) //001 for starting the conversion immediately
#define ADC_DONE   (1U<<31) //define it as unsigned value or compiler will throw #61-D warning
#define ADCR_SETUP_SCM ((CLKDIV<<8) | PWRUP)
int pot = 0;
int pot_10bit = 0;
float out = 0;
int volts = 0;
uint8_t state;
void Tache_Pot( void* pvParameters) {
    while(1){
        vTaskDelay(echantillonage_codeur);

        //Demmarage de la conversion
			
        LPC_ADC->ADCR |= START_CNV; //Start new Conversion

		while((LPC_ADC->ADDR0 & ADC_DONE) == 0); //Wait untill conversion is finished
		
		pot = (LPC_ADC->ADDR0) & 0xFFF0; //12 bit Mask to extract result
		
		volts = (pot*3300)/4096; //Convert result to Voltage
		
		printf("AD0.0 = %dmV\n" , volts); //Display milli-volts
			//printf("erreur"); //Display milli-volts
			pot_10bit  = pot & 0xFFC0;
			out = (pot_10bit*VREF)*1024;
		//	printf("out = %dmV\n", (int)out);
    LPC_DAC->DACR = pot_10bit; 
    }
}
void tache_bouton(void* pvParameters){
	while(1){
		vTaskDelay(100);
	if (LPC_GPIO0->FIOPIN & (1<<9))
	  {
		state = 0;
			LPC_GPIO2->FIODIR |=(1<<13); //set P2.13 pin as output
	LPC_GPIO2->FIOCLR       |=(1 << 13);      // LED defined as an output HIGH p2.13
		}
		else
		{
		state = 1;
			
	  }
		printf("state : %d\n", state);
	}
}
void vInit_myTasks(UBaseType_t uxPriority ){
	//xTaskCreate( Tache_Encod, "ENCOD", ledSTACK_SIZE, &delay, uxPriority, NULL );
	xTaskCreate( Tache_Pot, "ADC", ledSTACK_SIZE, NULL, uxPriority, NULL );
	xTaskCreate( tache_bouton, "bouton", ledSTACK_SIZE, NULL, uxPriority+1, NULL );
}
