
#ifndef MYTASKS_LED_H
#define MYTASKS_LED_H

void vInit_myTasks( UBaseType_t uxPriority );

#endif
