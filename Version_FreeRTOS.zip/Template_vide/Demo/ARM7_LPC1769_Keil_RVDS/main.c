
/* Standard includes. */
#include <stdlib.h>
// pour le lpc1769
#include "FreeRTOS.h"
#include "task.h"
#include "myTasks.h"
#include "ocf_lpc176x_lib.h"
/* Priorities for the demo application tasks. */
#define mainLED_TASK_PRIORITY		( tskIDLE_PRIORITY + 2 )

#define VREF       3.3 //Reference Voltage at VREFP pin, given VREFN = 0V(GND)
#define ADC_CLK_EN (1<<12)
#define SEL_AD0_0  (1<<0) //Select Channel AD0.0 
#define CLKDIV     1 //ADC clock-divider (ADC_CLOCK=PCLK/CLKDIV+1) = 12.5Mhz @ 25Mhz PCLK
#define PWRUP      (1<<21) //setting it to 0 will power it down
#define START_CNV  (1<<24) //001 for starting the conversion immediately
#define ADC_DONE   (1U<<31) //define it as unsigned value or compiler will throw #61-D warning
#define ADCR_SETUP_SCM ((CLKDIV<<8) | PWRUP)

 // Configuration minimal du processeur pour avoir les 8 Leds du Port2 disponible
 
static void prvSetupHardware( void );
static void init_gpio(void);
static void init_ADC(void) 
{
    LPC_SC->PCONP |= ADC_CLK_EN; //Enable ADC clock
	LPC_ADC->ADCR =  ADCR_SETUP_SCM | SEL_AD0_0;
	LPC_PINCON->PINSEL1 |= (1<<14) ; //select AD0.0 for P0.23
	
	LPC_PINCON->PINSEL1 |= (1<<21);
}
/*-----------------------------------------------------------*/
void gestion_abort(void)
{


}


/*
 * Application entry point:
 * Starts all the other tasks, then starts the scheduler. 
 */
int main( void )
{
 // Configuration minimal du processeur pour avoir les 8 Leds du Port2 disponible
	initUART0();
	init_ADC();
	LPC_GPIO0 ->FIODIR &= ~(1<<9); //set P0.9 as input
	prvSetupHardware();
	//init des leds
	init_gpio();
	/* initialisation des taches */
	vInit_myTasks( 2 );
	
	// toutes les taches ont �t� d�marr�es - Demarrer le scheduler.
  // Les taches tournent en USER/SYSTEM mode et le Scheduler tourne en Superviseur mode
	// Le processeur doit �tre en SUPERVISEUR quand vTaskStartScheduler est appel�
  // mais user privileged suffit en fait...	
	
	vTaskStartScheduler();

	/* Should never reach here!  If you do then there was not enough heap
	available for the idle task to be created. */
    LPC_GPIO3->FIOCLR = 1<<26;
		LPC_GPIO0->FIOCLR = 1<<22;
    LPC_GPIO3->FIOCLR = 1<<25;
	for( ;; )
	{ 
		LPC_GPIO3->FIOSET = 1<<26;
		LPC_GPIO0->FIOCLR = 1<<22;
    LPC_GPIO3->FIOSET = 1<<25;
	}
}

static void prvSetupHardware( void )
{
	//   SCS|=1;  // port 0 et Port 1 en FastIO
	LPC_SC->PCONP     |= (1 << 15);            /* power on sur GPIO & IOCON , deja sous tension par d�faut*/
  LPC_GPIO3->FIODIR |= 0x03<<25;   //P3.25 et P3.26 en sortie
	LPC_GPIO0->FIODIR |= 0x01<<22;   //P0.22 en sortie
}
static void init_gpio(void)
{ 
	LPC_SC->PCONP     |= (1 << 15);  /* power on sur GPIO & IOCON , deja sous tension par d�faut*/ 
  LPC_GPIO3->FIODIR |= 0x03<<25;   //P3.25 et P3.26 en sortie
  LPC_GPIO0->FIODIR |= 0x01<<22;   //P0.22 en sortie
    
  LPC_GPIO2->FIODIR |= 0x1F8; //P2.4 � P2.8 en sortie     
  LPC_GPIO0->FIODIR |= 0x01 <<11; //P0.11 en sortie (led)
	
} 
