/*(C) Umang Gajera - www.ocfreaks.com
LPC1768/LPC1769 ADC Interfacing Example 1 Source Code using KEIL ARM
More Embedded tutorials @ www.ocfreaks.com/cat/embedded/
License : GPL.*/

#include <lpc17xx.h>
#include "ocf_lpc176x_lib.h"
#include <stdio.h>  

